import * as React from "react";
import { useState, useEffect, useMemo } from "react";
import {
  StyleSheet,
  View,
  Dimensions,
  ActivityIndicator,
  Text,
  TouchableOpacity,
} from "react-native";
import Pdf from "react-native-pdf"; // This line requires the package
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons } from "@expo/vector-icons";

// Settings key
const SETTINGS_STORAGE_KEY = "pdfly_app_settings";

interface PDFViewerProps {
  uri: string;
  style?: object;
}

interface PDFSettings {
  autoRotate: boolean;
  highQualityRendering: boolean;
  enablePageTurningAnimation: boolean;
}

const PDFViewer = ({ uri, style }: PDFViewerProps): JSX.Element => {
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(0);
  const [scale, setScale] = useState<number>(1.0);
  const [settings, setSettings] = useState<PDFSettings>({
    autoRotate: true,
    highQualityRendering: true,
    enablePageTurningAnimation: true,
  });

  // Load user settings
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const savedSettings = await AsyncStorage.getItem(SETTINGS_STORAGE_KEY);
        if (savedSettings) {
          const parsedSettings = JSON.parse(savedSettings);
          setSettings({
            autoRotate: parsedSettings.autoRotate ?? true,
            highQualityRendering: parsedSettings.highQualityRendering ?? true,
            enablePageTurningAnimation:
              parsedSettings.enablePageTurningAnimation ?? true,
          });
        }
      } catch (error) {
        console.error("Error loading PDF viewer settings:", error);
      }
    };

    loadSettings();
  }, []);

  // Memoize the source to prevent unnecessary re-renders
  const source = useMemo(() => ({
    uri,
    cache: true,
    enableAntialiasing: settings.highQualityRendering,
    enableAnnotationRendering: settings.highQualityRendering,
  }), [uri, settings.highQualityRendering]);

  const zoomIn = () => {
    setScale((prevScale) => Math.min(prevScale + 0.2, 3.0));
  };

  const zoomOut = () => {
    setScale((prevScale) => Math.max(prevScale - 0.2, 0.5));
  };

  const resetZoom = () => {
    setScale(1.0);
  };

  return (
    <View style={[styles.container, style]}>
      {loading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a86e8" />
          <Text style={styles.loadingText}>Loading PDF...</Text>
        </View>
      )}

      {error && (
        <View style={styles.errorContainer}>
          <Ionicons name="alert-circle-outline" size={48} color="#ff6b6b" />
          <Text style={styles.errorText}>Failed to load PDF</Text>
          <Text style={styles.errorSubtext}>
            The file may be corrupted or in an unsupported format.
          </Text>
        </View>
      )}

      <Pdf
        source={source}
        onLoadComplete={(numberOfPages) => {
          console.log(`PDF loaded with ${numberOfPages} pages`);
          setTotalPages(numberOfPages);
          setLoading(false);
        }}
        onPageChanged={(page) => {
          console.log(`Current page: ${page}`);
          setCurrentPage(page);
        }}
        onError={(error) => {
          console.log("PDF error:", error);
          setError(true);
          setLoading(false);
        }}
        onPressLink={(uri) => {
          console.log(`Link pressed: ${uri}`);
        }}
        style={styles.pdf}
        enablePaging={settings.enablePageTurningAnimation}
        horizontal={false}
        enableRTL={false}
        fitPolicy={0} // Width
        spacing={10}
        scale={scale}
        enableAntialiasing={settings.highQualityRendering}
        enableAnnotationRendering={settings.highQualityRendering}

      />

      {/* Page indicator */}
      <View style={styles.pageIndicator}>
        <Text style={styles.pageText}>
          {currentPage} / {totalPages}
        </Text>
      </View>

      {/* Zoom controls */}
      <View style={styles.zoomControls}>
        <TouchableOpacity style={styles.zoomButton} onPress={zoomOut}>
          <Ionicons name="remove" size={20} color="#fff" />
        </TouchableOpacity>

        <TouchableOpacity style={styles.zoomButton} onPress={resetZoom}>
          <Ionicons name="refresh" size={20} color="#fff" />
        </TouchableOpacity>

        <TouchableOpacity style={styles.zoomButton} onPress={zoomIn}>
          <Ionicons name="add" size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start", // Corrected from "flex-rt"
    alignItems: "center",
    backgroundColor: "#F5FCFF",
  },
  loadingContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1,
    backgroundColor: "rgba(255, 255, 255, 0.9)",
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: "#4a86e8",
  },
  errorContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1,
    backgroundColor: "#fff",
    padding: 20,
  },
  errorText: {
    marginTop: 16,
    fontSize: 18,
    fontWeight: "bold",
    color: "#ff6b6b",
  },
  errorSubtext: {
    marginTop: 8,
    fontSize: 14,
    color: "#888",
    textAlign: "center",
  },
  pdf: {
    flex: 1,
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height,
    backgroundColor: "#F5FCFF",
  },
  pageIndicator: {
    position: "absolute",
    bottom: 20,
    alignSelf: "center",
    backgroundColor: "rgba(0, 0, 0, 0.6)",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  pageText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "500",
  },
  zoomControls: {
    position: "absolute",
    right: 16,
    bottom: 80,
    flexDirection: "column",
    alignItems: "center",
  },
  zoomButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "rgba(0, 0, 0, 0.6)",
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 4,
  },
});

export default PDFViewer;