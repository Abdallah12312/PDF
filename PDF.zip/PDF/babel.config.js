module.exports = function (api) {
  api.cache(true);
  return {
    presets: [
      // Configure jsxImportSource for Expo SDK 49+ with NativeWind v4
      ['babel-preset-expo', { jsxImportSource: 'nativewind' }],
      // Add nativewind/babel preset
      'nativewind/babel',
    ],
    plugins: [
      // Add other plugins here if needed

      // IMPORTANT: 'react-native-reanimated/plugin' must be the last plugin listed
      'react-native-reanimated/plugin',
    ],
  };
};