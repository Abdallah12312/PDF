import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  View,
  Text,
  SafeAreaView,
  StatusBar,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { NavigationContainer, DarkTheme as NavDarkTheme, DefaultTheme as NavDefaultTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Import screens
import HomeScreen from "./screen/HomeScreen"; // Corrected path
import PDFViewerScreen from "./screen/PDFViewerScreen"; // Corrected path
import SettingsScreen from "./screen/SettingsScreen"; // Corrected path

// Settings key
const SETTINGS_STORAGE_KEY = "pdfly_app_settings";

export type RootStackParamList = {
  MainTabs: undefined;
  PDFViewer: { uri: string; title: string };
};

export type BottomTabParamList = {
  Home: undefined;
  Settings: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<BottomTabParamList>();


// Main tab navigator
const MainTabs = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === "Home") {
            iconName = focused ? "home" : "home-outline";
          } else if (route.name === "Settings") {
            iconName = focused ? "settings" : "settings-outline";
          }

          return <Ionicons name={iconName as any} size={size} color={color} />;
        },
        tabBarActiveTintColor: "#4a86e8",
        tabBarInactiveTintColor: "gray",
        headerStyle: {
          backgroundColor: "#4a86e8",
        },
        headerTintColor: "#fff",
        headerTitleStyle: {
          fontWeight: "bold",
        },
      })}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: "PDFly",
        }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          title: "Settings",
        }}
      />
    </Tab.Navigator>
  );
};

export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Load app settings
    const loadSettings = async () => {
      try {
        const savedSettings = await AsyncStorage.getItem(SETTINGS_STORAGE_KEY);
        if (savedSettings) {
          const settings = JSON.parse(savedSettings);
          setDarkMode(settings.darkMode || false);
        }
      } catch (error) {
        console.error("Error loading app settings:", error);
      } finally {
        setIsReady(true);
      }
    };

    loadSettings();

    // Listen for settings changes
    const onChange = async (key: string) => {
      if (key === SETTINGS_STORAGE_KEY) {
        try {
          const savedSettings = await AsyncStorage.getItem(SETTINGS_STORAGE_KEY);
          if (savedSettings) {
            const settings = JSON.parse(savedSettings);
            setDarkMode(settings.darkMode || false);
          }
        } catch (error) {
          console.error("Error handling settings change:", error);
        }
      }
    };

    // Manually poll for changes since AsyncStorage.onChange is not reliable
    const intervalId = setInterval(async () => {
      const keys = await AsyncStorage.getAllKeys();
      keys.forEach(onChange);
    }, 1000);

    return () => {
      clearInterval(intervalId);
    };
  }, []);

  if (!isReady) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#4a86e8" />
      </View>
    );
  }

  return (
    <NavigationContainer
      theme={darkMode ? DarkTheme : LightTheme}
      onReady={() => console.log('NavigationContainer is ready')}
      onStateChange={(state) => console.log('Navigation state:', state)}
      fallback={<ActivityIndicator size="large" color="#4a86e8" />}
    >
      <StatusBar
        barStyle={darkMode ? "light-content" : "dark-content"}
        backgroundColor={darkMode ? "#121212" : "#ffffff"}
      />
      <Stack.Navigator initialRouteName="MainTabs">
        <Stack.Screen
          name="MainTabs"
          component={MainTabs}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="PDFViewer"
          component={PDFViewerScreen}
          options={({ route }) => {
            console.log('PDFViewer route params:', route.params);
            return {
              title: route.params?.title || "PDF Viewer",
              headerStyle: {
                backgroundColor: "#4a86e8",
              },
              headerTintColor: "#fff",
            };
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Use react-navigation's built-in themes with custom primary color
const LightTheme = {
  ...NavDefaultTheme,
  colors: {
    ...NavDefaultTheme.colors,
    primary: "#4a86e8",
  },
};

const DarkTheme = {
  ...NavDarkTheme,
  colors: {
    ...NavDarkTheme.colors,
    primary: "#4a86e8",
  },
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
});
