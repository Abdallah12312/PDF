import React from "react";
import { StyleSheet, View, SafeAreaView } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import PDFViewer from "../components/PDFViewer";
// Removed AdBanner import

type RootStackParamList = {
  MainTabs: undefined;
  PDFViewer: { uri: string; title: string };
};

type PDFViewerScreenProps = NativeStackScreenProps<
  RootStackParamList,
  "PDFViewer"
>;


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
  },
  // Removed banner styles
  pdfViewer: {
    flex: 1,
  },
  // Removed banner styles
});

export default PDFViewer;
