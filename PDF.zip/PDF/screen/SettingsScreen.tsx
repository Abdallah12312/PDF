import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  View,
  Text,
  Switch,
  TouchableOpacity,
  Alert,
  ScrollView,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons } from "@expo/vector-icons";

// Settings keys
const SETTINGS_STORAGE_KEY = "pdfly_app_settings";

interface AppSettings {
  darkMode: boolean;
  autoRotate: boolean;
  showAds: boolean;
  highQualityRendering: boolean;
  enablePageTurningAnimation: boolean;
}

const DEFAULT_SETTINGS: AppSettings = {
  darkMode: false,
  autoRotate: true,
  showAds: true,
  highQualityRendering: true,
  enablePageTurningAnimation: true,
};

const SettingsScreen: React.FC = () => {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async (): Promise<void> => {
    try {
      const savedSettings = await AsyncStorage.getItem(SETTINGS_STORAGE_KEY);
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      }
    } catch (error) {
      console.error("Error loading settings:", error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async (newSettings: AppSettings): Promise<void> => {
    try {
      await AsyncStorage.setItem(
        SETTINGS_STORAGE_KEY,
        JSON.stringify(newSettings),
      );
      setSettings(newSettings);
    } catch (error) {
      console.error("Error saving settings:", error);
      Alert.alert("Error", "Failed to save settings");
    }
  };

  const toggleSetting = (key: keyof AppSettings): void => {
    const newSettings = { ...settings, [key]: !settings[key] };
    saveSettings(newSettings);
  };

  const resetSettings = (): void => {
    Alert.alert(
      "Reset Settings",
      "Are you sure you want to reset all settings to default?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Reset",
          style: "destructive",
          onPress: () => saveSettings(DEFAULT_SETTINGS),
        },
      ],
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading settings...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <AdBanner style={styles.topBanner} />

      <ScrollView style={styles.scrollView}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Appearance</Text>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons
                name="moon-outline"
                size={22}
                color="#4a86e8"
                style={styles.settingIcon}
              />
              <Text style={styles.settingLabel}>Dark Mode</Text>
            </View>
            <Switch
              value={settings.darkMode}
              onValueChange={() => toggleSetting("darkMode")}
              trackColor={{ false: "#d1d1d1", true: "#81b0ff" }}
              thumbColor={settings.darkMode ? "#4a86e8" : "#f4f3f4"}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PDF Viewer</Text>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons
                name="sync-outline"
                size={22}
                color="#4a86e8"
                style={styles.settingIcon}
              />
              <Text style={styles.settingLabel}>Auto-rotate Pages</Text>
            </View>
            <Switch
              value={settings.autoRotate}
              onValueChange={() => toggleSetting("autoRotate")}
              trackColor={{ false: "#d1d1d1", true: "#81b0ff" }}
              thumbColor={settings.autoRotate ? "#4a86e8" : "#f4f3f4"}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons
                name="speedometer-outline"
                size={22}
                color="#4a86e8"
                style={styles.settingIcon}
              />
              <Text style={styles.settingLabel}>High Quality Rendering</Text>
            </View>
            <Switch
              value={settings.highQualityRendering}
              onValueChange={() => toggleSetting("highQualityRendering")}
              trackColor={{ false: "#d1d1d1", true: "#81b0ff" }}
              thumbColor={settings.highQualityRendering ? "#4a86e8" : "#f4f3f4"}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons
                name="book-outline"
                size={22}
                color="#4a86e8"
                style={styles.settingIcon}
              />
              <Text style={styles.settingLabel}>Page Turning Animation</Text>
            </View>
            <Switch
              value={settings.enablePageTurningAnimation}
              onValueChange={() => toggleSetting("enablePageTurningAnimation")}
              trackColor={{ false: "#d1d1d1", true: "#81b0ff" }}
              thumbColor={
                settings.enablePageTurningAnimation ? "#4a86e8" : "#f4f3f4"
              }
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Ads</Text>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons
                name="pricetag-outline"
                size={22}
                color="#4a86e8"
                style={styles.settingIcon}
              />
              <Text style={styles.settingLabel}>Show Advertisements</Text>
            </View>
            <Switch
              value={settings.showAds}
              onValueChange={() => toggleSetting("showAds")}
              trackColor={{ false: "#d1d1d1", true: "#81b0ff" }}
              thumbColor={settings.showAds ? "#4a86e8" : "#f4f3f4"}
            />
          </View>
        </View>

        <TouchableOpacity style={styles.resetButton} onPress={resetSettings}>
          <Text style={styles.resetButtonText}>Reset to Default Settings</Text>
        </TouchableOpacity>

        <View style={styles.aboutSection}>
          <Text style={styles.appName}>PDFly</Text>
          <Text style={styles.appVersion}>Version 1.0.0</Text>
          <Text style={styles.appCopyright}>© 2023 Your Company</Text>
        </View>
      </ScrollView>

      <AdBanner style={styles.bottomBanner} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  topBanner: {
    marginVertical: 8,
    marginHorizontal: 16,
  },
  bottomBanner: {
    marginVertical: 8,
    marginHorizontal: 16,
  },
  scrollView: {
    flex: 1,
  },
  section: {
    backgroundColor: "#fff",
    borderRadius: 8,
    marginHorizontal: 16,
    marginVertical: 8,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 12,
  },
  settingItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  settingInfo: {
    flexDirection: "row",
    alignItems: "center",
  },
  settingIcon: {
    marginRight: 12,
  },
  settingLabel: {
    fontSize: 15,
    color: "#333",
  },
  resetButton: {
    backgroundColor: "#ff6b6b",
    borderRadius: 8,
    padding: 16,
    margin: 16,
    alignItems: "center",
  },
  resetButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 15,
  },
  aboutSection: {
    alignItems: "center",
    padding: 24,
    marginBottom: 16,
  },
  appName: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
  },
  appVersion: {
    fontSize: 14,
    color: "#888",
    marginTop: 4,
  },
  appCopyright: {
    fontSize: 12,
    color: "#aaa",
    marginTop: 8,
  },
});

export default SettingsScreen;
