import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Alert,
  Platform,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import {
  pickPDFDocument,
  loadPDFMetadata,
  savePDFMetadata,
  deletePDFFile,
} from "../utils/fileManager";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";

type PDFFile = {
  id: string;
  name: string;
  uri: string;
  size: number;
};

type HomeScreenProps = {
  navigation: NativeStackNavigationProp<any>;
};

const HomeScreen: React.FC<HomeScreenProps> = ({ navigation }) => {
  const [pdfFiles, setPdfFiles] = useState<PDFFile[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Load saved PDFs from storage when component mounts
    loadSavedPDFs();
  }, []);

  const loadSavedPDFs = async (): Promise<void> => {
    try {
      setLoading(true);
      const savedPDFs = await loadPDFMetadata();
      setPdfFiles(savedPDFs);
    } catch (error) {
      console.error("Error loading saved PDFs:", error);
      Alert.alert("Error", "Failed to load saved PDFs");
    } finally {
      setLoading(false);
    }
  };

  const handleAddPDF = async (): Promise<void> => {
    try {
      const newPdf = await pickPDFDocument();

      if (newPdf) {
        const updatedPdfs = [...pdfFiles, newPdf];
        setPdfFiles(updatedPdfs);
        await savePDFMetadata(updatedPdfs);
      }
    } catch (error) {
      console.error("Error adding document:", error);
      Alert.alert("Error", "Failed to add document");
    }
  };

  const handleDeletePDF = async (pdfId: string): Promise<void> => {
    try {
      Alert.alert("Delete PDF", "Are you sure you want to delete this PDF?", [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            const updatedPdfs = await deletePDFFile(pdfId, pdfFiles);
            if (updatedPdfs) {
              setPdfFiles(updatedPdfs);
            } else {
              Alert.alert("Error", "Failed to delete PDF");
            }
          },
        },
      ]);
    } catch (error) {
      console.error("Error deleting PDF:", error);
      Alert.alert("Error", "Failed to delete PDF");
    }
  };

  const openPDF = async (pdf: PDFFile): Promise<void> => {
    navigation.navigate("PDFViewer", {
      uri: pdf.uri,
      title: pdf.name,
    });
  };

  const renderItem = ({ item }: { item: PDFFile }) => (
    <TouchableOpacity style={styles.fileItem} onPress={() => openPDF(item)}>
      <Ionicons name="document-text-outline" size={24} color="#4a86e8" />
      <View style={styles.fileInfo}>
        <Text style={styles.fileName} numberOfLines={1}>
          {item.name}
        </Text>
        <Text style={styles.fileSize}>
          {(item.size / 1024 / 1024).toFixed(2)} MB
        </Text>
      </View>
      <TouchableOpacity
        onPress={() => handleDeletePDF(item.id)}
        style={styles.deleteButton}
      >
        <Ionicons name="trash-outline" size={20} color="#ff6b6b" />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {pdfFiles.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="document-text-outline" size={64} color="#ccc" />
          <Text style={styles.emptyText}>No PDF files yet</Text>
          <Text style={styles.emptySubtext}>
            Tap the button below to add a PDF
          </Text>
        </View>
      ) : (
        <FlatList
          data={pdfFiles}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
        />
      )}

      <TouchableOpacity style={styles.addButton} onPress={handleAddPDF}>
        <Ionicons name="add" size={24} color="#fff" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: "#888",
    marginTop: 8,
    textAlign: "center",
  },
  listContainer: {
    padding: 16,
  },
  fileItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  fileInfo: {
    flex: 1,
    marginLeft: 12,
  },
  fileName: {
    fontSize: 16,
    fontWeight: "500",
    color: "#333",
  },
  fileSize: {
    fontSize: 12,
    color: "#888",
    marginTop: 4,
  },
  deleteButton: {
    padding: 8,
  },
  addButton: {
    position: "absolute",
    right: 24,
    bottom: 80, // Adjusted to make room for bottom banner
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: "#4a86e8",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 5,
  },
});

export default HomeScreen;
