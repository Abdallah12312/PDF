import * as FileSystem from "expo-file-system";
import * as DocumentPicker from "expo-document-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Key for storing PDF references in AsyncStorage
const PDF_STORAGE_KEY = "pdfly_saved_pdfs";

// Directory for storing PDF files
const PDF_DIRECTORY = `${FileSystem.documentDirectory}pdfs/`;

// PDF metadata interface
export interface PDFMetadata {
  id: string;
  name: string;
  uri: string;
  size: number;
  dateAdded: string;
}

// Ensure the PDF directory exists
const ensurePDFDirectoryExists = async (): Promise<void> => {
  const dirInfo = await FileSystem.getInfoAsync(PDF_DIRECTORY);
  if (!dirInfo.exists) {
    await FileSystem.makeDirectoryAsync(PDF_DIRECTORY, { intermediates: true });
  }
};

// Save PDF metadata to AsyncStorage
const savePDFMetadata = async (pdfs: PDFMetadata[]): Promise<boolean> => {
  try {
    await AsyncStorage.setItem(PDF_STORAGE_KEY, JSON.stringify(pdfs));
    return true;
  } catch (error) {
    console.error("Error saving PDF metadata:", error);
    return false;
  }
};

// Load PDF metadata from AsyncStorage
const loadPDFMetadata = async (): Promise<PDFMetadata[]> => {
  try {
    const data = await AsyncStorage.getItem(PDF_STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error loading PDF metadata:", error);
    return [];
  }
};

// Pick a PDF document from device
const pickPDFDocument = async (): Promise<PDFMetadata | null> => {
  try {
    const result = await DocumentPicker.getDocumentAsync({
      type: "application/pdf",
      copyToCacheDirectory: true,
    });

    if (result.assets && result.assets.length > 0) {
      // Ensure PDF directory exists
      await ensurePDFDirectoryExists();

      // Generate a unique filename
      const timestamp = Date.now();
      const newFileName = `${timestamp}_${result.assets?.[0]?.name || 'untitled.pdf'}`;
      const newUri = `${PDF_DIRECTORY}${newFileName}`;

      // Copy the file to our app's documents directory
      await FileSystem.copyAsync({
        from: result.assets?.[0]?.uri || '',
        to: newUri,
      });

      // Return metadata about the saved PDF
      return {
        id: timestamp.toString(),
        name: result.assets?.[0]?.name || 'untitled.pdf',
        uri: newUri,
        size: result.assets?.[0]?.size || 0,
        dateAdded: new Date().toISOString(),
      };
    }
    return null;
  } catch (error) {
    console.error("Error picking document:", error);
    throw error;
  }
};

// Delete a PDF file
const deletePDFFile = async (
  pdfId: string,
  pdfs: PDFMetadata[],
): Promise<PDFMetadata[] | false> => {
  try {
    // Find the PDF in our list
    const pdfToDelete = pdfs.find((pdf) => pdf.id === pdfId);
    if (!pdfToDelete) return false;

    // Delete the file
    await FileSystem.deleteAsync(pdfToDelete.uri);

    // Remove from our list
    const updatedPdfs = pdfs.filter((pdf) => pdf.id !== pdfId);

    // Save updated list
    await savePDFMetadata(updatedPdfs);

    return updatedPdfs;
  } catch (error) {
    console.error("Error deleting PDF:", error);
    return false;
  }
};

export { pickPDFDocument, loadPDFMetadata, savePDFMetadata, deletePDFFile };
